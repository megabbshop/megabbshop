<?php 

//just an example of a php file with will run if installed via extension installer.
<?php
/*
*  location: admin/controller
*/

require_once(DIR_APPLICATION.'controller/extension/d_shopunity.php');
class ControllerExtensionModuleDShopunity extends ControllerExtensionDShopunity
{   
    public function __construct($registry)
    {
        parent::__construct($registry);
    }
}
?>

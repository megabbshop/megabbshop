<?php
$_['heading_title'] = 'Shopunity';
$_['text_edit'] = 'Extensions';
